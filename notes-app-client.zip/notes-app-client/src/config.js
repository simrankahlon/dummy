export default {
  s3: {
    REGION: "ap-south-1",
    BUCKET: "oneanswer.co"
  },
  apiGateway: {
    REGION: "ap-south-1",
    URL: "https://gcfv3kst9f.execute-api.ap-south-1.amazonaws.com/dev/search"
  },
  cognito: {
    REGION: "ap-south-1",
    USER_POOL_ID: "ap-south-1_7kj8isnSi",
    APP_CLIENT_ID: "54rou7nsorl71sqq0pva2q2hcr",
    IDENTITY_POOL_ID: "ap-south-1:42083587-e198-407f-a152-d1c1f94a29a0"
  }
};