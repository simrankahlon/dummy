import React, { Component } from "react";
import "./Home.css";
import Amplify from "aws-amplify";
import { API } from "aws-amplify";
import config from "../config";

export default class Home extends Component {

  callLambdaFunction()
  {
        return API.get(config.apiGateway.URL, {
          body: 'Hello'
        });
  }
  render() {
    return (
      <div className="Home">
        <div className="lander">
          <h1>One Answer</h1>
          <p>An answer to all your questions</p>
          <input type="text" id="searchquestion" className="searchquestion" name="searchquestion"/><button id="search" className="search" name="search" type="submit" onClick={() => this.callLambdaFunction()}>Search</button>
        </div>
      </div>
    );
  }
}